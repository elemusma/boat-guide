$(document).ready(function() {

  $(".burger-nav").on("click", function() {
    $(".navigation.menu").toggleClass("open");
  })

})
